# sl

> Steam locomotive running through your terminal.
> More information: <https://github.com/mtoyoda/sl>.

- Let a steam locomotive run through your terminal:

`sl`

- The train burns, people scream:

`sl -a`

- Let the train fly:

`sl -F`

- Make the train little:

`sl -l`

- Let the user exit (CTRL + C):

`sl -e`
