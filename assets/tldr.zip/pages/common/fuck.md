# fuck

> Corrects your previous console command.
> More information: <https://github.com/nvbn/thefuck>.

- Set the `fuck` alias to `thefuck` tool:

`eval "$(thefuck --alias)"`

- Try to match a rule for the previous command:

`fuck`
