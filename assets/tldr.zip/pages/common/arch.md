# arch

> Display the name of the system architecture.
> See also `uname`.

- Display the system's architecture:

`arch`
