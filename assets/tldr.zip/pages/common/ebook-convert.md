# ebook-convert

> Can be used to convert ebooks between common formats, e.g., pdf, epub and mobi.
> Part of the Calibre ebook library tool.
> More information: <https://manual.calibre-ebook.com/generated/en/ebook-convert.html>.

- Convert an ebook into another format:

`ebook-convert {{source}} {{destination}}`
