# ver

> Display the current Windows or MS-DOS version number.

- Display the current version number:

`ver`
