# assoc

> Display or modify file extension associations.

- Display all associated filetypes:

`assoc`

- Display the associated filetype for a specific extension:

`assoc {{.txt}}`

- Modify the associated filetype for a specific extension:

`assoc {{.txt}}={{txtfile}}`
