# choco feature

> Interact with features with Chocolatey.
> More information: <https://chocolatey.org/docs/commands-feature>.

- Display a list of available features:

`choco feature list`

- Enable a feature:

`choco feature enable --name {{name}}`

- Disable a feature:

`choco feature disable --name {{name}}`
