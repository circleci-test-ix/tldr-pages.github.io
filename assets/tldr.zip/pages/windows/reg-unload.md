# reg unload

> Remove data from the registry that was loaded using the `reg load` command.

- Remove data from the registry for a specified key:

`reg unload {{key_name}}`
