# pwlauncher

> A command line tool for managing the Windows To Go startup options.

- Display the current Windows To Go status:

`pwlauncher`

- Enable or disable the Windows To Go startup options:

`pwlauncher /{{enable|disable}}`
