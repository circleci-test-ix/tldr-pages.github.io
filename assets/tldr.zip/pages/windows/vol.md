# vol

> Display information about volumes.

- Display the label and serial number for the current drive:

`vol`

- Display the label and serial number for a specific volume:

`vol {{D:}}`
