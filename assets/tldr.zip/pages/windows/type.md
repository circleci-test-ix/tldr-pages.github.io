# type

> Display the contents of a file.

- Display the contents of a specific file:

`type {{path/to/file}}`
