# title

> Set the title of the command prompt window.

- Set the title of the current command prompt window:

`title {{new_title}}`
