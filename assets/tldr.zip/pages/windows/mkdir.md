# mkdir

> Creates a directory.

- Create a directory:

`mkdir {{directory_name}}`

- Recursively create a nested directory tree:

`mkdir {{path/to/sub_directory_name}}`
