# clip

> Copy input content to the Windows clipboard.

- Pipe command line output to the Windows clipboard:

`{{dir}} | clip`

- Copy the contents of a file to the Windows clipboard:

`clip < {{path/to/file}}`
