# exit

> Quit the current CMD instance or the current batch file.

- Quit the current CMD instance:

`exit`

- Quit the current batch script:

`exit /b`

- Quit using a specific exit code:

`exit {{exit_code}}`
