# reg restore

> Restore a key and its values from a backup file.
> See `reg-save` for more information.

- Overwrite a specified key with data from a backup file:

`reg restore {{key_name}} {{path/to/file}}`
