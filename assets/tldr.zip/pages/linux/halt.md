# halt

> Power off or reboot the machine.

- Power the machine off:

`halt`

- Reboot the machine:

`halt --reboot`
