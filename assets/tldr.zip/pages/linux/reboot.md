# reboot

> Reboot the system.

- Reboot immediately:

`reboot`

- Reboot immediately without gracefully shutdown:

`reboot -f`
